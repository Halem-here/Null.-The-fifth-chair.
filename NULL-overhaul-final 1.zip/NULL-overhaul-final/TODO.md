# NULL — Outcome Checklist

This checklist preserves the acceptance requirements from `writing-block.md`. Statuses describe the current implementation, not whether a line of code was merely attempted.

## 1. Preserve the story and its evidence boundaries — Complete (working-draft limits documented)

- Preserve the established NULL story and character canon.
- Preserve all seven main endings while improving their logic, consequences, and dialogue variations.
- Do not invent evidence, character actions, motives, timelines, or revelations that are unsupported by the existing canon.
- Do not resolve intentionally open mysteries simply to give the story a conventional ending.
- Do not sacrifice logical consistency for dramatic twists or visual effects.
- The current working facts remain: MIST capsized at 20:41; Dess's phone sent “All safe.” at 21:52; the first emergency call was recorded at 22:40; Arlo was found at 07:10 the following morning; the coroner's record does not establish his exact time of death.
- The 48-minute interval does not independently establish why the call was delayed, whether an earlier voice call was possible, whether Arlo was alive at 21:52, or whether the delay affected his death.
- Dess admits sending the misleading message to stop Arlo's mother from calling; this does not prove that she caused Arlo's death or untied the rope. Teo's account about agreeing what to say remains testimony.
- Preserve the recorded votes: Dess TRUE, Corin TRUE, Teo NULL, Livia NULL, Nell FALSE. The later unanimous-NULL account is inaccurate; do not automatically infer who introduced it or why.
- Livia's admission establishes impersonation only for the messages covered by her admission. It does not prove that she knows Nell's whereabouts or that every message attributed to Nell was forged.
- Nell's page does not establish whether she left, where she went, or whether she is alive. Teo's memory does not establish that the dragged object was Nell's bag.
- There were five friends and five chairs. The fifth chair represents Nell's absence and missing perspective; it is not an extra chair for Arlo or evidence of a supernatural event.
- The supplied brief notes a possible conflict between an earlier GOLDIE instruction and the current working draft's MIST. Preserve the current implementation and document the unresolved decision unless an authoritative source resolves it.
- Keep the tone psychologically unsettling, concise and natural. Distinguish deliberate lying, imperfect memory and accurate statements that misrepresent significance. Do not make every character an obvious suspect or repeat information the player already knows.

## 2. Evidence records, links and claim rules — Complete

- Create a complete internal source-to-claim matrix before making further story-content changes.
- Each evidence item should have a stable identifier and, where relevant, these fields: source identifier; source type; exact factual content; relevant character or event; related evidence identifiers; claims supported; claims contradicted; confidence or evidentiary status; known limitations; unresolved questions.
- Use the existing architecture where practical. Do not duplicate story data across multiple files when a shared source of truth is feasible.
- Maintain these distinctions: **Verified record** (what a reliable record directly establishes); **Testimony** (what a character claims, remembers, or reports); **Contradiction** (two claims or records that cannot both be true in the same relevant sense and context); **Inference** (a conclusion the player draws); **Unresolved** (a question the available evidence does not justify deciding).
- A contradiction must not be generated merely because two accounts sound different. Check exact wording, context, timing and scope. Emotional reactions are never proof of guilt.
- The original vote sheet must be a discoverable, evidence-backed contradiction to the later claim that everyone voted NULL. It establishes that the later claim is inaccurate; it does not automatically reveal who introduced it or why.
- Preserve and correctly connect the capsizing, 21:52 message and 22:40 call; Dess's explanation and Teo's account; the original vote and the later unanimous account; Nell's page and messages attributed to her; Livia's impersonation; Teo's dragged-object memory; and the unresolved rope question.
- Do not treat all of those threads as confirmed contradictions. For each, document what the player can establish, what remains plausible and what cannot be concluded. If a deduction lacks enough evidence, identify the gap instead of inventing a clue.

## 3. Investigation workspace and saved player material — Complete

- Reduce repetitive tab-switching and rereading without removing the intellectual challenge.
- Implement or improve a compact investigation workspace using the existing architecture where possible. It must support: a persistent evidence collection; pinned evidence; personal notes; open questions; side-by-side evidence comparison; links between related statements and records; and a clear distinction between source material and the player's own conclusions.
- A compact clipboard or investigation-panel control may open a side panel without navigating away from the current screen.
- Preserve notes and pins across navigation and reloads using an appropriate storage mechanism. Handle missing, invalid or outdated saved data gracefully.
- Do not automatically reveal the correct answer when clues are compared. Present relevant source material and let the player reason.
- Give enough context to explain why a clue matters without explaining the entire deduction. Avoid arbitrary clue locking, unnecessary backtracking and repetitive reading; difficulty should come from reasoning, not interface friction.

## 4. Seven endings, final report and verdict logic — Complete (existing identities/gates preserved)

- Preserve the existing TRUE / FALSE / NULL verdict mechanic. Inspect how verdicts are stored, validated, evaluated and connected to the seven endings before modifying them.
- Preserve the existing seven-ending structure and inspect its established names, conditions, dialogue and story details before applying the proposed narrative identities: The Careful Record; The Pattern; The Accusation; The Convenient Story; The Fifth Chair; The False Voice; and NULL. Resolve differences through canon verification rather than replacing content automatically.
- Each main ending must have a distinct central decision, meaningful outcome and final narrative beat.
- The Careful Record direction: distinguish established facts from unknowns and submit a defensible report; variations may reflect whether important contradictions were identified.
- The Pattern direction: connect meaningful evidence across accounts and records, while distinguishing a real pattern from an unsupported claim that every event was coordinated.
- The Accusation direction: reflect whether the specific claim is supported; selecting an accusation must never make it proof.
- The Convenient Story direction: show the omissions and limitations that follow when the player accepts a simplified account or omits material contradictions.
- The Fifth Chair direction: acknowledge what Nell's records establish and what remains unknown.
- The False Voice direction: recognise Livia's impersonation without automatically assuming she knows Nell's fate.
- The NULL direction: use uncertainty precisely; a weak variation may show that NULL was used to avoid evaluating evidence that could support a more definite conclusion.
- The final report should allow the player to express a conclusion while distinguishing established claims, contradicted claims, supported interpretations and unresolved claims. Do not force a definitive verdict without evidence or allow the player to classify everything as NULL without considering available records.
- The final report should communicate what the player established, what remains uncertain and where their conclusions exceed the evidence. Evaluate the reasoning and evidence behind the report, not simply the number of TRUE, FALSE and NULL selections.

## 5. Hidden evaluation — Complete (no numeric UI output)

- Never display scores, percentages, grades, stars, rankings, internal variable names or labels such as “best ending” to the player.
- Internally assess three separate dimensions: evidence accuracy (including relevant records and contradictions); reasoning quality (distinguishing facts, testimony, inference and uncertainty, and avoiding unsupported claims); and final report (claims submitted, qualified or omitted, and whether evidence limits are communicated accurately).
- Do not equate the number of collected clues with reasoning quality. A strong conclusion may rely on a smaller but sufficient body of relevant evidence.
- Avoid a simplistic single score that controls everything. Prefer transparent, deterministic internal rules based on existing claims, evidence relationships and choices.
- In this implementation, evidence accuracy is reflected in evidence classifications, invalid strikes and claim support; reasoning is reflected in the distinction between records/accounts/guesses and retelling choices; the final report is reflected in its verdicts, addressee and ending-specific gates. These remain separate internal factors, not one aggregate player-facing number or a newly invented scoring scale.
- Ending variations may change dialogue, report wording, which contradictions are addressed, which limitations remain visible and the final scene's emphasis.
- Use conditional dialogue and consequences to communicate reasoning quality. For example, if the player establishes that Livia impersonated Nell but claims that this proves Livia knows Nell's whereabouts, acknowledge the impersonation and identify the unsupported inference.
- A character's denial or confession must not automatically validate the player's theory. Avoid arbitrary punishment, hidden gotchas and outcomes that require guessing the developer's preferred interpretation.
- Consequences must be understandable through the story, without showing internal evaluation scores.

## 6. Visual design, accessibility, mobile and languages — Complete (Chromium verified; physical-device coverage remains open)

- Keep the existing visual direction: near-black backgrounds; restrained dark-red accents; muted neutral supporting colours; clear readable typography; documentary and archival elements; subtle transitions and carefully controlled glitch effects; atmospheric photography or original assets where appropriate; and readable evidence cards, timelines, interview records and investigation board.
- The experience should feel like a designed investigative dossier, not a generic admin dashboard or ordinary card collection. Animation must not interfere with reading, interaction, performance or accessibility.
- Ensure adequate contrast, visible keyboard focus, meaningful labels, appropriate heading structure and reduced-motion support.
- **Mobile language switcher:** Use a clean three-horizontal-line hamburger. Keep its treatment subtle and suited to NULL's dark psychological-mystery aesthetic. Tapping/clicking opens a small, well-positioned English/Roman Urdu dropdown near mobile navigation, without overlapping nav items, the logo or other controls; make it work at mobile breakpoints without horizontal overflow. Animate the bars smoothly and subtly into an X while open and back to three lines when closed. Close after a language is selected, when tapping outside, or on Escape where supported. Preserve the existing translation system and selected language; do not add untranslated UI. Keep the desktop language buttons unchanged.
- **Notes shortcut and panel:** Remove Notes from the navigation items so players do not have to scroll the nav or switch tabs to reach notes. Add a fixed bottom-right Notes shortcut, visible across relevant investigation tabs, with a discoverable but restrained notebook/notes icon, refined dark background and subtle red accent/shadow consistent with NULL. Keep it accessible and visible against varied content on desktop and mobile, respect mobile safe-area insets, and reserve content space so it does not cover evidence, text, navigation, submission controls or other interactive elements. Open Notes in a mobile bottom sheet/drawer and a suitable desktop side panel/drawer. Closing returns the player to the same tab and scroll position. Preserve notebook functionality and reliable local autosave on every edit; notes/questions persist across navigation and reload within the current local-storage architecture. Keep keyboard close/focus behavior and responsive layout.
- **Brand signature:** Place the exact text `| by 850101 |` directly under the existing NULL logo/wordmark, with balanced spacing, smaller type, muted grey and tasteful tracking. Keep it understated, legible and aligned on mobile and desktop. Do not alter the NULL logo's proportions, typography, appearance or identity; add no surrounding text, logo, emoji or decoration.
- Preserve NULL's near-black atmosphere, restrained dark-red accents, established typography and visual language. Avoid excessive borders, oversized/standard-dashboard buttons, bright colors, flashy motion, unnecessary cards or unrelated redesigns. Reuse the current static architecture and translation system; do not add a framework or dependency. Add accessible keyboard controls, focus handling and labels; honor reduced-motion settings. Do not change story/evidence, interviews, contradiction logic, final report or hidden ending evaluation.
- Verify English and Roman Urdu dropdown behavior, hamburger/X and dismissal paths, Notes open/close on all relevant tabs, notes persistence across navigation/reload, mobile safe-area/layout across phone/tablet/desktop widths, overlap/overflow, browser errors, and all existing story/evidence/report/seven-ending behavior. Run existing project tests. Report only checks actually run.
- Final verified run: `node tests/run.js` — 130 passed, 0 failed; `python3 tests/browser.py` — 328 passed, 0 failed in Chromium/Playwright.
- The language toggle must never overlap navigation items such as Evidence, Interviews or Report. At narrow widths, use deliberate compact navigation or a proper menu; keep language controls accessible; prevent horizontal overflow; keep evidence cards and timelines readable; make comparison interfaces usable without repeated navigation; keep dialogs and panels within the viewport; make targets comfortable to use; and avoid clipped text, overlapping controls or inaccessible hidden content.
- Preserve English and Pakistani Roman Urdu. Do not use Devanagari. Translate all visible interface text, navigation, evidence, interviews, validation messages, endings and error states.
- Switching language must not reset the investigation, change decisions or lose notes and pinned evidence. Use the existing consistent translation system rather than scattered inline language conditionals; test missing translations and fallback behaviour.
- Test multiple viewport sizes rather than relying on a single responsive breakpoint.

## 7. Code quality, architecture and deployment — Partial (no production host supplied)

- Treat the supplied codebase as the source of truth; preserve working features and use its conventions unless a genuine defect requires a change.
- Do not replace the project wholesale. Keep code readable and maintainable, with clear responsibilities. Comments should explain non-obvious decisions, edge cases or constraints; they must not restate the next line. Avoid unnecessary comments, artificial complexity, overengineering and huge functions that mix unrelated concerns.
- Do not introduce unnecessary frameworks, dependencies, APIs, databases or services. Do not use an AI API or paid service unless explicitly approved. Do not add fake backend functionality. If the existing static architecture meets requirements, keep it static.
- Validate data at appropriate boundaries. Avoid silent failures, inconsistent state, duplicate sources of truth and race conditions where applicable. Do not hardcode environment-specific secrets or expose private keys in client-side code.
- Inspect deployment configuration and fix genuine problems. Verify the correct entry point and build output; relative asset paths; all referenced JavaScript, CSS, images, fonts and data files; imports and missing files; no development-only dependencies; direct navigation and refresh where supported; no unexpected console/network errors; language and saved state across navigation/reload; all seven endings reachable through valid choices with correct variations; and usable desktop/mobile layouts.
- Do not assume selecting an “Other” framework or technology option fixes deployment issues. Diagnose the actual build and hosting configuration.

## 8. Regression coverage and verification — Complete (other browsers/devices untested)

- Build on existing tests rather than replacing them with superficial smoke tests. Add regression coverage for each genuine bug fixed.
- Evidence integrity must check that every referenced evidence ID exists; source-to-claim relationships point to valid records; confirmed contradictions have explicit supporting evidence; unsupported inferences are not labelled established facts; and the original vote and unanimous-NULL claim are represented correctly.
- Timeline integrity must check consistent timestamps, the correct 48-minute interval, and no unsupported time or cause of death.
- Story integrity must check that Livia's admission does not reveal Nell's fate; Nell's page does not prove where she went or whether she is alive; Teo's memory does not identify the dragged object automatically; and the rope mystery remains unresolved unless evidence justifies a conclusion.
- Ending integrity must check all seven endings remain reachable; selection is deterministic for the same state; meaningful variations appear where appropriate; hidden evaluation never leaks scores; unsupported accusations receive evidence-based consequences; legitimate uncertainty is not punished; and reload/language switching do not corrupt ending state.
- Frontend integrity must check English and Roman Urdu on all screens; no missing translations; no overlapping navigation/language controls; no unintended horizontal scrolling; keyboard access; correct persistence of notes and pins; and no unexpected console errors, failed requests or broken assets.
- Run the existing automated test suite, build checks and available browser tests. If a test cannot run because a dependency or browser is unavailable, state that limitation rather than claiming success.

## 9. Handoff — Complete

The completed delivery must include: (1) actual bugs found and fixed; (2) story and evidence changes, distinguishing canon-preserving fixes from approved narrative changes; (3) the final source-to-claim and contradiction mapping; (4) an explanation of the seven endings and hidden evaluation rules; (5) frontend, accessibility and mobile improvements; (6) exact tests and build commands with real results; (7) unresolved canon conflicts, evidence gaps and untested behaviour; and (8) clear instructions for running and deploying the project.

Do not claim the website is fully functional, secure or deployment-ready unless the available tests support those claims. The target experience lets the player investigate without unnecessary frustration, discover real contradictions, distinguish testimony from fact, form and test theories, and submit a report whose consequences reflect the quality of their reasoning. The mystery should remain unsettling because evidence has limits, not because logic is broken: preserve the story's uncertainty while eliminating accidental ambiguity in code, evidence relationships and interface.
