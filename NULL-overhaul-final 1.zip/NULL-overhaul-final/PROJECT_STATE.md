# NULL — Project State

Last updated: 2026-10-24. This ZIP is the current self-contained working draft. There is no separate authoritative canon packet in the supplied files; `STORY_BIBLE.md` describes the working story and `CANON_AUDIT.md` records its limits. `EVIDENCE_MATRIX.md` is generated from the current evidence, relation, claim and art-note data.

## A. Run and deployment

- **NULL — The Fifth Chair** is a static, offline HTML/CSS/JavaScript browser mystery. It has no backend, build framework, external API, database, remote fonts or network dependency.
- Recommended local run: from this directory, run `python3 -m http.server 8000`, then open `http://localhost:8000`. Save data stays in that browser profile. Directly opening `index.html` may behave differently depending on browser storage policy.
- The title screen offers English and Pakistani Roman Urdu in Latin script. On screens 560px wide or narrower, an accessible hamburger animates into an X while the choices are open; desktop keeps the direct language buttons. Escape, outside clicks and language selection close the mobile menu. Language preference is stored separately from investigation progress. The exact creator signature `| by 850101 |` sits beneath the NULL wordmark.
- No production hosting provider was supplied and the project has not been deployed. For a static host, publish this project root as-is so `index.html`, `css/`, `js/`, `assets/` and `locales/` retain their relative paths; there is no build step.

## B. Project map

- `index.html`, `css/style.css` — static shell, accessible controls and responsive presentation.
- `js/data-facts.js` — shared event times and unsupported-time guards.
- `js/data-cards.js`, `js/data-interviews.js`, `js/data-story.js`, `js/data-links.js` — cards, testimony, claim rules, timeline, endings and evidence relations.
- `js/engine.js` — investigation state, evidence rules, save repair, verdicts and ending eligibility.
- `js/art.js`, `js/ui-kit.js`, `js/ui.js` — art metadata, rendering, screens, notebook and interactions.
- `js/i18n.js`, `js/data-locale.js` — offline translation runtime and generated bundle.
- `locales/roman-urdu/*.json`, `tools/build-locale.py` — editable Pakistani Roman Urdu translations and bundle builder. Current catalog: 869 exact entries and 90 patterns.
- `tests/run.js`, `tests/browser.py`, `tests/probes/` — engine/data regressions, Chromium integration checks and a diagnostic probe.
- `STORY_BIBLE.md`, `CANON_AUDIT.md`, `EVIDENCE_MATRIX.md`, `TODO.md`, `CHANGELOG.md`, `plan.md` — working story, evidence map, acceptance checklist, history and project notes.
- `backup/` — source archive copies retained from the uploaded project.

## C. Evidence and story safeguards

- The working boat name is `MIST`; Arlo Penn is the victim. The original brief also notes an unresolved earlier `GOLDIE` instruction. No supplied authority resolves it, so this update preserves `MIST` and documents the conflict.
- The current source has 34 evidence cards, 10 verdict claims, 24 case-board links and one explicit contradiction: the vote sheet `c12` contradicts the later unanimous-NULL account `d05`. That contradiction establishes that the later account is inaccurate; it does not identify who introduced it or why.
- Nell's 18:26 message says she is “nearly there” and asks for the window seat. There is no arrival time in the file. The 18:30 claim was removed from stale translation entries and is guarded by regression tests.
- The 21:52 message and 22:40 call are 48 minutes apart. The records do not prove when a voice call became possible, why the group waited, whether Arlo was alive at 21:52, or whether the delay affected his death.
- Livia's interview admission and the SIM record support impersonation only within the scope of her admission. They do not establish Nell's whereabouts or Livia's knowledge of them. Teo does not identify the dragged object; the rope actor and intent remain unresolved.
- Read `EVIDENCE_MATRIX.md` for every card's source, status, related records, claim role and limits. Relevant links do not automatically satisfy a verdict rule.

## D. Investigation workspace and save behavior

- The fixed bottom-right Notes shortcut opens a side drawer on desktop and a bottom sheet on mobile, without leaving the current screen. Pins, questions, notes and game progress are stored in the local browser save; they are not sent to a server.
- Notes and pins survive reloads and language switches. Save validation handles malformed or outdated data without overwriting the stored file until play continues.
- The UI presents evidence-specific qualitative explanations, not numeric scores, percentages, grades, rankings or a “best ending” label.

## E. Current ending gates

The existing seven ending names and gate order are preserved. Every ending requires a complete three-part retelling and an addressee. The engine checks:

1. **STRUCK** — incorrect-strike weight reaches 6.
2. **THE SAME SENTENCE** — at least two retelling choices repeat the group's agreed line.
3. **NELL / THE FIVE** — addressee Nell; Wren-forwarded flag; correct timeline and pages answers; `x02` and `x04` Fact; claims `k1`, `k3`, `k5`, `k6`, `k7`, `k9` supported.
4. **THE CARD** — addressee Livia; SIM found and `x03` Fact; Livia trust at least 2; claims `k7` and `k8` supported.
5. **THE LETTER** — addressee Wren; trust at least 4; Wren-forwarded flag; `x02` and `x04` Fact; claims `k1`, `k3`, `k7`, `k9` supported.
6. **THE FIVE** — all eight core claims (`k1`, `k3`–`k9`) supported.
7. **NO ANSWER** — fallback when the completed report does not meet another gate.

The internal evaluation remains deterministic and multi-factor (including incorrect strikes, supported claims, retelling choices, recipient and ending-specific requirements). The UI gives qualitative reasons and never presents a numeric result.

## F. Verification

Latest completed checks:

- `python3 tools/build-locale.py` — **869 exact entries, 90 patterns**.
- `node tests/run.js` — **130 passed, 0 failed**. Includes evidence-map references, the single confirmed contradiction, 18:26 without an arrival event, stale Roman Urdu-copy guards, notes/save migration, claims and seven ending routes.
- `python3 tests/browser.py` — **328 passed, 0 failed** in Chromium/Playwright. Covers English and Roman Urdu on phone and desktop layouts, all seven endings, notebook/pin persistence, mobile hamburger/X and dismissal behavior, Notes access across investigation tabs, the open-book shortcut icon and label, drawer/sheet geometry after animation settles, assets, missing translations, keyboard interactions, overflow and browser errors/requests.
- Full-game viewport coverage includes 390×844 touch emulation and 1280×800 desktop; the language dropdown also fits at 320px without horizontal overflow. This is not Safari, Firefox or real-device certification.
- JavaScript syntax checks passed for project scripts; Python compile and all editable Roman Urdu JSON parse checks passed.
- `node tests/probes/ending-gates.js` was run as a diagnostic, not a pass/fail suite. It intentionally reached `NO ANSWER` with the probe's incomplete state (no judged `k7`, sign-off answer or `x02`); the main regression suite separately covers all seven reachable routes.

Re-run with `python3 tools/build-locale.py`, `node tests/run.js` and `python3 tests/browser.py`. Browser checks require Playwright Chromium.

## G. Limits and open decisions

- The files form a working story draft, not an assertion of an external canon. The MIST/GOLDIE conflict remains for the author to resolve.
- A full human literary read-through of all English dialogue and Roman Urdu has not been completed. Automated translation checks confirm coverage/rendering, not literary quality.
- Only Chromium was used. Safari, Firefox, real phones and production-host deployment have not been tested.
- The project remains static and offline; no server-side storage, encryption or shared-account service is provided for player notes.
