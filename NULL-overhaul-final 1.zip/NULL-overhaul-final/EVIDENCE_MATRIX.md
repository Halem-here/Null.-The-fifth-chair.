# NULL — Evidence-to-Claim Matrix

This is an internal map of the supplied working draft, not a claim of external canon. It is generated from the current card, claim, relation and art-note data. The game’s `ART.CLAIM_CARDS` index marks relevance; only each claim’s explicit `needs`, `needsAccount` and conditional flags define its current ruling gate. A linked or relevant card is not automatically proof.

**Coverage:** 34 evidence cards, 10 verdict claims, 24 case-board links, and 1 explicit contradiction.

## Status key

- **Fact** — the game treats a record as establishing the content it directly records; it does not establish facts outside that scope.
- **Told** — one person’s account. It may matter, but is not an independent record of the event.
- **Guessed** — unsupported assertion or uncertain recollection; not proof.
- **Struck** — contradicted by a Fact card. Unproven does not mean false.
- **Supports / consistent / uncertain** are case-board relation labels. They do not create a verdict by themselves.

## Card-by-card source map

### `c01` — Photograph, 20:41

- **Source:** Records — Logs, photographs, documents.
- **Game status:** Fact
- **Exact card content:** “Taken on Teo’s phone. The boat, MIST, is on its side. One person is on the hull. One person is in the water, holding another person’s arm. Nobody else is in the frame.”
- **Related evidence:**
  - `l01` — **Consistent** (`consistent`): The photograph shows one person in the water holding another’s arm. Livia says she got Nell to the hull. The photograph does not name anyone.
  - `c05` — **Consistent** (`consistent`): The photograph is from 20:41. Arlo was found at 07:10 the next morning. Neither says when he died.
- **Claim mapping:**
  - `k1` — MIST capsized at Greywater, and Arlo Penn was later found drowned. (required Fact record for the listed TRUE/FALSE rule).
  - `k2` — Livia rescued Nell from the water. (required Fact record for the listed TRUE/FALSE rule).
- **Known limitation:** Shows: A boat on its side at 20:41. One person on the hull. One person in the water holding another’s arm.; Cannot show: It does not show who anyone is, or where Arlo was.

### `c02` — Message to Mrs Penn, 21:52

- **Source:** Records — Logs, photographs, documents.
- **Game status:** Fact
- **Exact card content:** “Sent from Dess’s phone. Two words: “All safe.” At 21:52 the phone was on the Greywater beach cell sector.”
- **Related evidence:**
  - `c03` — **Supports** (`supports`): “All safe.” was sent at 21:52, from the beach. The first call to the emergency line was at 22:40. That is 48 minutes later. The text does not show whether a voice call was possible then. The records do not say why the gap happened, or whether the wait changed anything.
  - `d02` — **Supports** (`supports`): Dess says the message was hers. The record shows it was sent from her phone.
  - `c04` — **Consistent** (`consistent`): Mr Okafor saw about four people on the beach “some time after nine”, with no time noted. The 21:52 message came from that beach. Neither one tells you when the group arrived.
  - `d04` — **Uncertain** (`uncertain`): The text was sent from a beach cell sector at 21:52. That does not show where the phone was earlier, whether voice calls worked there, or when the group could call for help.
- **Claim mapping:**
  - `k3` — The records prove the group could have made an emergency voice call at 21:52. (relevant context; this card alone does not satisfy the verdict rule).
  - `k4` — Arlo was still alive when “All safe.” was sent. (relevant context; this card alone does not satisfy the verdict rule).
- **Known limitation:** Shows: A phone on the beach sent “All safe.” at 21:52.; Cannot show: It does not show whether Arlo was alive, or what Dess knew.

### `c03` — Emergency call log

- **Source:** Records — Logs, photographs, documents.
- **Game status:** Fact
- **Exact card content:** “The first call to the emergency line was received at 22:40. It came from the Hartwell landline.”
- **Related evidence:**
  - `c02` — **Supports** (`supports`): “All safe.” was sent at 21:52, from the beach. The first call to the emergency line was at 22:40. That is 48 minutes later. The text does not show whether a voice call was possible then. The records do not say why the gap happened, or whether the wait changed anything.
  - `d01` — **Uncertain** (`uncertain`): Dess says they got to shore and called when they could. The log gives the time of the first call, but not when a voice call became possible. The records do not prove or disprove her timing.
  - `t02` — **Consistent** (`consistent`): Teo says Dess wanted everyone to get their stories straight before calling. The log gives the time of the first call, but his account is still just his word.
  - `r01` — **Uncertain** (`uncertain`): Corin says he heard they called when they could. He was at the dock, not on the boat, and never checked what he was told.
- **Claim mapping:**
  - `k3` — The records prove the group could have made an emergency voice call at 21:52. (relevant context; this card alone does not satisfy the verdict rule).
- **Known limitation:** Shows: The first call to the emergency line came at 22:40.; Cannot show: It does not show when the group reached the shore, or why they waited.

### `c04` — Mr Okafor’s statement

- **Source:** Records — Logs, photographs, documents.
- **Game status:** Told
- **Exact card content:** “Mr Okafor lives on the lake road. He says he saw about four people sitting on Greywater beach “some time after nine, not moving much.” He did not note the time.”
- **Related evidence:**
  - `c02` — **Consistent** (`consistent`): Mr Okafor saw about four people on the beach “some time after nine”, with no time noted. The 21:52 message came from that beach. Neither one tells you when the group arrived.
- **Claim mapping:** no direct entry in the current claim index.
- **Known limitation:** Shows: Someone outside the group saw about four people on the beach after nine.; Cannot show: No time was noted. It does not say when they arrived.

### `c05` — Coroner’s note

- **Source:** Records — Logs, photographs, documents.
- **Game status:** Fact
- **Exact card content:** “Arlo Penn was found at 07:10 the next morning, on the east shore. Cause of death: drowning. The note does not say when he died.”
- **Related evidence:**
  - `c01` — **Consistent** (`consistent`): The photograph is from 20:41. Arlo was found at 07:10 the next morning. Neither says when he died.
- **Claim mapping:**
  - `k1` — MIST capsized at Greywater, and Arlo Penn was later found drowned. (required Fact record for the listed TRUE/FALSE rule).
- **Known limitation:** Shows: Arlo drowned and was found at 07:10 the next morning.; Cannot show: It does not give a time of death.

### `c06` — Forum post: “teo untied the rope”

- **Source:** Records — Logs, photographs, documents.
- **Game status:** Guessed
- **Exact card content:** “Posted eleven days after the capsize by an account that has since been deleted: “teo untied the rope, everyone knows.” There are no replies, no evidence and no name.”
- **Related evidence:**
  - `t01` — **Uncertain** (`uncertain`): An anonymous post accuses Teo with no source. Teo’s own “maybe me” is not an admission. Two unsupported statements do not add up to proof.
- **Claim mapping:**
  - `k5` — The file proves who untied MIST’s rope and that they meant to cause harm. (relevant context; this card alone does not satisfy the verdict rule).
- **Known limitation:** Shows: Someone posted a rumour about Teo.; Cannot show: There is no name, no source and no evidence behind it.

### `c07` — Nell’s text, 18:26, October 2016

- **Source:** Records — Logs, photographs, documents.
- **Game status:** Fact
- **Exact card content:** “Sent to the house group: “nearly there. save me the seat by the window. -- N.” The file records no arrival time.”
- **Timeline use:** Nell texts: “nearly there”
- **Related evidence:** no explicit case-board edge in the current data.
- **Claim mapping:** no direct entry in the current claim index.
- **Known limitation:** Shows: At 18:26, Nell texted that she was nearly there.; Cannot show: The file gives no record of when she arrived.

### `c08` — Dess’s notebook, 22:55

- **Source:** Records — Logs, photographs, documents.
- **Game status:** Told
- **Exact card content:** “A page in Dess’s handwriting: “front door bolted 22:55.” It does not say who bolted it. It is the only record that the door was bolted.”
- **Timeline use:** Front door bolted (Dess’s notebook)
- **Related evidence:** no explicit case-board edge in the current data.
- **Claim mapping:** no direct entry in the current claim index.
- **Known limitation:** Shows: Dess wrote that the front door was bolted at 22:55.; Cannot show: It does not say who bolted it. It is Dess’s own note.

### `c11` — Dock light camera, 01:15

- **Source:** Records — Logs, photographs, documents.
- **Game status:** Fact
- **Exact card content:** “One still frame, taken at 01:15. It shows the dock, the post and the water. No boat and no person. It does not show what happened before or after.”
- **Timeline use:** Dock camera: no boat, no person
- **Related evidence:** no explicit case-board edge in the current data.
- **Claim mapping:**
  - `k9` — Nell is dead. (relevant context; this card alone does not satisfy the verdict rule).
- **Known limitation:** Shows: No boat and no person at the dock at 01:15.; Cannot show: One moment only. It does not show where anyone went, or anything about Nell’s phone.

### `c12` — Vote sheet, 22:40

- **Source:** Records — Logs, photographs, documents.
- **Game status:** Fact
- **Exact card content:** “In Corin’s handwriting. Statement: “What happened to Arlo was nobody’s fault.” Dess TRUE. Corin TRUE. Teo NULL. Livia NULL. Nell FALSE.”
- **Timeline use:** The vote
- **Related evidence:**
  - `d05` — **Contradiction**: The vote sheet records two TRUE votes, two NULL votes and one FALSE vote, not a unanimous NULL.
- **Claim mapping:**
  - `k6` — The 2016 vote was unanimous. (required Fact record for the listed TRUE/FALSE rule).
- **Known limitation:** Shows: How each of the five voted.; Cannot show: It does not say why anyone voted as they did.

### `b01` — Bus depot clerk

- **Source:** Records — Logs, photographs, documents.
- **Game status:** Guessed
- **Exact card content:** “Two days after the vote, a clerk at the bus depot said: “A girl with a green pack, early morning, bought a ticket north. Could have been her. I see a lot of girls with packs.””
- **Related evidence:**
  - `n02` — **Uncertain** (`uncertain`): A depot clerk thinks a girl with a green pack “could have been her”, and says he sees a lot of girls with packs.
- **Claim mapping:**
  - `k9` — Nell is dead. (relevant context; this card alone does not satisfy the verdict rule).
- **Known limitation:** Shows: A clerk thinks he saw a girl with a green pack buy a ticket north.; Cannot show: He is not sure it was Nell. It does not show she took that bus.

### `n01` — Page 1, handwritten

- **Source:** Nell — Handwritten pages and her old texts.
- **Game status:** Fact
- **Exact card content:** ““I’d like one of you to say it happened. That’s all I want. Not why. Not whose. -- N.””
- **Related evidence:**
  - `n02` — **Consistent** (`consistent`): The two handwritten pages follow one another: what she asked for, and what she will do if nobody gives it.
- **Claim mapping:**
  - `k10` — Nell wrote that she had packed and would not come back to the table. (relevant context; this card alone does not satisfy the verdict rule).
- **Known limitation:** Shows: What Nell asked of the group.; Cannot show: It does not say where she went or what she did next.

### `n02` — Page 2, handwritten

- **Source:** Nell — Handwritten pages and her old texts.
- **Game status:** Fact
- **Exact card content:** ““If nobody will, I’m not coming back to the table. I’ve packed. Wren knows where I’ll be, or will. -- N.””
- **Related evidence:**
  - `n01` — **Consistent** (`consistent`): The two handwritten pages follow one another: what she asked for, and what she will do if nobody gives it.
  - `t03` — **Uncertain** (`uncertain`): Nell wrote that she had packed. Teo heard something heavy dragged downstairs: “a bag, I think.” Whose bag it was is not shown.
  - `b01` — **Uncertain** (`uncertain`): A depot clerk thinks a girl with a green pack “could have been her”, and says he sees a lot of girls with packs.
- **Claim mapping:**
  - `k9` — Nell is dead. (relevant context; this card alone does not satisfy the verdict rule).
  - `k10` — Nell wrote that she had packed and would not come back to the table. (required Fact record for the listed TRUE/FALSE rule).
- **Known limitation:** Shows: Nell wrote that she had packed, and would not come back unless someone said it happened.; Cannot show: It does not show where she went, or whether she got there.

### `n03` — Text to Livia, Sep 2015

- **Source:** Nell — Handwritten pages and her old texts.
- **Game status:** Fact
- **Exact card content:** ““ok. i’m alive because of you. i don’t know what to do with that. -- N.””
- **Related evidence:**
  - `l01` — **Supports** (`supports`): Nell’s own text says she is alive because of Livia. Livia says she pulled Nell to the hull.
- **Claim mapping:**
  - `k2` — Livia rescued Nell from the water. (required Fact record for the listed TRUE/FALSE rule).
- **Known limitation:** Shows: Nell wrote that she was alive because of Livia.; Cannot show: It does not say how Livia saved her.

### `d01` — Dess: “when we could”

- **Source:** Dess Hartwell
- **Game status:** Told
- **Exact card content:** ““We got ashore and called when we could.””
- **Related evidence:**
  - `c03` — **Uncertain** (`uncertain`): Dess says they got to shore and called when they could. The log gives the time of the first call, but not when a voice call became possible. The records do not prove or disprove her timing.
- **Claim mapping:** no direct entry in the current claim index.
- **Known limitation:** Shows: What Dess says the group did after they reached the beach.; Cannot show: It is one person’s account.

### `d02` — Dess on “All safe.”

- **Source:** Dess Hartwell
- **Game status:** Told
- **Exact card content:** ““His mother kept calling. I sent “All safe.” to get her to stop. I didn’t know if he was safe. I know how that sounds.””
- **Related evidence:**
  - `c02` — **Supports** (`supports`): Dess says the message was hers. The record shows it was sent from her phone.
  - `t02` — **Consistent** (`consistent`): Dess says she sent the text because Mrs Penn kept calling. Teo says Dess wanted the group to agree on what to tell people before calling. Different moments; both are second-hand accounts.
- **Claim mapping:**
  - `k4` — Arlo was still alive when “All safe.” was sent. (relevant context; this card alone does not satisfy the verdict rule).
- **Known limitation:** Shows: Dess says she sent the message, and did not know it was true.; Cannot show: It does not show what she thought about Arlo, or why nobody called sooner.

### `d03` — Dess on the rope

- **Source:** Dess Hartwell
- **Game status:** Told
- **Exact card content:** ““Arlo untied it. He was always messing with that rope.””
- **Related evidence:**
  - `r02` — **Uncertain** (`uncertain`): Dess says Arlo untied the rope. Corin thinks he saw Dess’s hands, but was looking from the shed and says he may be wrong. Neither account is independently confirmed.
  - `t01` — **Uncertain** (`uncertain`): Dess says Arlo untied the rope. Teo cannot remember whether he let go or untied it. His uncertainty does not establish that Dess or Arlo was wrong.
- **Claim mapping:**
  - `k5` — The file proves who untied MIST’s rope and that they meant to cause harm. (relevant context; this card alone does not satisfy the verdict rule).
- **Known limitation:** Shows: Dess says Arlo untied the rope himself.; Cannot show: It is one account, and others disagree. Nobody has confirmed it.

### `d04` — Dess: no signal

- **Source:** Dess Hartwell
- **Game status:** Told
- **Exact card content:** ““There wasn’t any signal down there. We had to get up to the house to call.””
- **Related evidence:**
  - `c02` — **Uncertain** (`uncertain`): The text was sent from a beach cell sector at 21:52. That does not show where the phone was earlier, whether voice calls worked there, or when the group could call for help.
- **Claim mapping:** no direct entry in the current claim index.
- **Known limitation:** Shows: Dess’s account of mobile signal after the capsize.; Cannot show: The 21:52 text does not establish where the phone was earlier or whether voice calls were possible.

### `d05` — Dess on the vote

- **Source:** Dess Hartwell
- **Game status:** Struck
- **Exact card content:** ““We all wrote NULL. None of us knew what had happened. That’s what the rule is for.””
- **Related evidence:**
  - `c12` — **Contradiction**: The vote sheet records two TRUE votes, two NULL votes and one FALSE vote, not a unanimous NULL.
- **Claim mapping:**
  - `k6` — The 2016 vote was unanimous. (relevant context; this card alone does not satisfy the verdict rule).
- **Known limitation:** Shows: Dess’s memory of how the vote went.; Cannot show: It is her memory, not the record of the vote.

### `r01` — Corin: what he heard

- **Source:** Corin Vale
- **Game status:** Guessed
- **Exact card content:** ““I heard they called when they could. That’s all I know.” Corin was at the dock, not on the boat.”
- **Related evidence:**
  - `c03` — **Uncertain** (`uncertain`): Corin says he heard they called when they could. He was at the dock, not on the boat, and never checked what he was told.
- **Claim mapping:** no direct entry in the current claim index.
- **Known limitation:** Shows: Corin’s version of what the group did.; Cannot show: Corin was at the dock. He did not see it himself.

### `r02` — Corin on the rope

- **Source:** Corin Vale
- **Game status:** Told
- **Exact card content:** ““Dess. I think. I was in the shed, looking for the bailer. I only saw hands.””
- **Related evidence:**
  - `d03` — **Uncertain** (`uncertain`): Dess says Arlo untied the rope. Corin thinks he saw Dess’s hands, but was looking from the shed and says he may be wrong. Neither account is independently confirmed.
  - `t01` — **Uncertain** (`uncertain`): Corin thinks he saw Dess’s hands, but says he may be wrong. Teo is unsure what he did. These accounts leave the rope unresolved.
- **Claim mapping:**
  - `k5` — The file proves who untied MIST’s rope and that they meant to cause harm. (relevant context; this card alone does not satisfy the verdict rule).
- **Known limitation:** Shows: Corin says he saw hands at the rope, and thinks they were Dess’s.; Cannot show: He saw only hands, from the shed. He says he is fairly sure, not certain.

### `t01` — Teo on the rope

- **Source:** Teo Brandt
- **Game status:** Guessed
- **Exact card content:** ““Could’ve been me, I guess. I had hold of the rope, then I didn’t. I can’t remember letting go. Don’t know if I untied it or just lost hold.””
- **Related evidence:**
  - `d03` — **Uncertain** (`uncertain`): Dess says Arlo untied the rope. Teo cannot remember whether he let go or untied it. His uncertainty does not establish that Dess or Arlo was wrong.
  - `r02` — **Uncertain** (`uncertain`): Corin thinks he saw Dess’s hands, but says he may be wrong. Teo is unsure what he did. These accounts leave the rope unresolved.
  - `c06` — **Uncertain** (`uncertain`): An anonymous post accuses Teo with no source. Teo’s own “maybe me” is not an admission. Two unsupported statements do not add up to proof.
- **Claim mapping:**
  - `k5` — The file proves who untied MIST’s rope and that they meant to cause harm. (relevant context; this card alone does not satisfy the verdict rule).
- **Known limitation:** Shows: Teo says he may have been holding the rope.; Cannot show: He does not remember. A “maybe” is not an admission.

### `t02` — Teo on the beach

- **Source:** Teo Brandt
- **Game status:** Told
- **Exact card content:** ““Dess said, ‘Let’s get our stories straight before we call anyone.’ She said we’d look worse if we all said different things. I just went along with it. I didn’t say anything.””
- **Related evidence:**
  - `c03` — **Consistent** (`consistent`): Teo says Dess wanted everyone to get their stories straight before calling. The log gives the time of the first call, but his account is still just his word.
  - `d02` — **Consistent** (`consistent`): Dess says she sent the text because Mrs Penn kept calling. Teo says Dess wanted the group to agree on what to tell people before calling. Different moments; both are second-hand accounts.
- **Claim mapping:** no direct entry in the current claim index.
- **Known limitation:** Shows: Teo says what Dess told the group on the beach, and that he did not argue.; Cannot show: It is Teo’s memory. Nobody else has confirmed it.

### `t03` — Teo, upstairs, 00:40

- **Source:** Teo Brandt
- **Game status:** Told
- **Exact card content:** ““I heard a door, then something heavy coming down the stairs. A bag, maybe. I stayed in my room.””
- **Timeline use:** Something dragged downstairs (Teo’s account)
- **Related evidence:**
  - `n02` — **Uncertain** (`uncertain`): Nell wrote that she had packed. Teo heard something heavy dragged downstairs: “a bag, I think.” Whose bag it was is not shown.
- **Claim mapping:**
  - `k10` — Nell wrote that she had packed and would not come back to the table. (relevant context; this card alone does not satisfy the verdict rule).
- **Known limitation:** Shows: Teo heard a door and something heavy dragged, at about 00:40.; Cannot show: He did not see it. He thinks it was a bag.

### `l01` — Livia on the rescue

- **Source:** Livia Marsh
- **Game status:** Told
- **Exact card content:** ““Nell got caught under the sail. I reached her, got her to the hull, then went back for Arlo. Twice. Couldn’t find him.””
- **Related evidence:**
  - `c01` — **Consistent** (`consistent`): The photograph shows one person in the water holding another’s arm. Livia says she got Nell to the hull. The photograph does not name anyone.
  - `n03` — **Supports** (`supports`): Nell’s own text says she is alive because of Livia. Livia says she pulled Nell to the hull.
- **Claim mapping:**
  - `k2` — Livia rescued Nell from the water. (required account in the file (Fact or Told)).
- **Known limitation:** Shows: Livia says she got Nell to the hull, then went back for Arlo.; Cannot show: It is Livia’s own account.

### `l02` — Livia at the door, 00:10

- **Source:** Livia Marsh
- **Game status:** Told
- **Exact card content:** ““I went to her door just after midnight. She told me to go away. She seemed calm. I told myself she was fine.””
- **Timeline use:** Livia at Nell’s door (Livia’s account)
- **Related evidence:** no explicit case-board edge in the current data.
- **Claim mapping:**
  - `k8` — Livia knows where Nell is. (relevant context; this card alone does not satisfy the verdict rule).
- **Known limitation:** Shows: Livia says she went to Nell’s door at about 00:10.; Cannot show: It is Livia’s own account. Nobody else saw it.

### `l03` — Livia: no number

- **Source:** Livia Marsh
- **Game status:** Told
- **Exact card content:** ““I don’t have her number any more.””
- **Related evidence:**
  - `x03` — **Uncertain** (`uncertain`): A SIM in Livia’s coat carried the number that sent the messages to Wren. That does not establish whether it was Nell’s number or whether Livia could reach Nell.
- **Claim mapping:**
  - `k8` — Livia knows where Nell is. (relevant context; this card alone does not satisfy the verdict rule).
- **Known limitation:** Shows: Livia says she no longer has Nell’s number.; Cannot show: The SIM linked to messages for Wren does not establish that it was Nell’s number or a way to reach her.

### `l04` — Livia on the messages

- **Source:** Livia Marsh
- **Game status:** Told
- **Exact card content:** ““The SIM’s in the lining of my coat. I used it to message Wren as Nell. I kept telling myself Wren needed to hear I was okay. I knew it wasn’t right. I don’t know where Nell is. I never did.””
- **Related evidence:**
  - `x03` — **Uncertain** (`uncertain`): Livia says she used the SIM in her coat to message Wren as Nell. The SIM record connects that card to the sending number; the admission is still her account, not an independent record of who typed each message.
- **Claim mapping:**
  - `k7` — Livia wrote the messages sent to Wren. (required account in the file (Fact or Told)).
  - `k8` — Livia knows where Nell is. (relevant context; this card alone does not satisfy the verdict rule).
- **Known limitation:** Shows: Livia says she used the SIM in her coat to message Wren as Nell.; Cannot show: This is her account of what she did. It does not show where Nell is or whether Livia knows.

### `w01` — Wren on the messages

- **Source:** Wren Ward
- **Game status:** Told
- **Exact card content:** ““Since last November, I’ve had fourteen messages. All short. All “I’m fine.”””
- **Related evidence:**
  - `x01` — **Consistent** (`consistent`): Wren describes fourteen short “I’m fine.” messages. This is the first of them.
- **Claim mapping:** no direct entry in the current claim index.
- **Known limitation:** Shows: Wren says she has received fourteen short messages since last November.; Cannot show: It shows what Wren received. It does not show who sent them.

### `w02` — Wren on the sign-off

- **Source:** Wren Ward
- **Game status:** Told
- **Exact card content:** ““Nell always put a dot after her name. Notes, texts, even receipts. These messages didn’t have one. I told myself it was just the phone. I wanted them to be from her.””
- **Related evidence:**
  - `x02` — **Supports** (`supports`): Wren remembers that the messages had no dot. The comparison shows it missing from every one.
- **Claim mapping:**
  - `k7` — Livia wrote the messages sent to Wren. (relevant context; this card alone does not satisfy the verdict rule).
- **Known limitation:** Shows: Wren remembers that Nell always used the dot.; Cannot show: It is Wren’s memory of Nell’s habit.

### `x01` — Message to Wren, 4 Nov 2016

- **Source:** The messages to Wren
- **Game status:** Told; conditional status: copiedProved → Struck
- **Exact card content:** ““I’m fine. Don’t look for me. -- N””
- **Related evidence:**
  - `w01` — **Consistent** (`consistent`): Wren describes fourteen short “I’m fine.” messages. This is the first of them.
- **Claim mapping:**
  - `k7` — Livia wrote the messages sent to Wren. (relevant context; this card alone does not satisfy the verdict rule).
- **Known limitation:** Shows: The first message Wren received.; Cannot show: It does not show who sent it.

### `x02` — Sign-off comparison

- **Source:** The messages to Wren
- **Game status:** Fact
- **Exact card content:** “Nell’s pages and her own texts end “-- N.” The fourteen messages to Wren end “-- N”. Every one, with no exception.”
- **Related evidence:**
  - `x04` — **Supports** (`supports`): Every message to Wren has a different sign-off from Nell’s own, and every one came from a single prepaid number that was not Nell’s usual number. Neither fact names the sender.
  - `w02` — **Supports** (`supports`): Wren remembers that the messages had no dot. The comparison shows it missing from every one.
- **Claim mapping:**
  - `k7` — Livia wrote the messages sent to Wren. (relevant context; this card alone does not satisfy the verdict rule).
- **Known limitation:** Shows: The messages to Wren are signed differently from Nell’s own writing.; Cannot show: A different sign-off is a reason to doubt, not proof of who wrote them.

### `x03` — Prepaid SIM card

- **Source:** The messages to Wren
- **Game status:** Fact
- **Exact card content:** “A prepaid SIM card was found in the lining of Livia’s coat. Its number is the number that sent the messages to Wren.”
- **Related evidence:**
  - `l03` — **Uncertain** (`uncertain`): A SIM in Livia’s coat carried the number that sent the messages to Wren. That does not establish whether it was Nell’s number or whether Livia could reach Nell.
  - `x04` — **Supports** (`supports`): The SIM in the coat lining has the number that sent all fourteen messages. That links the SIM to the messages, not to the person who wrote them or to Nell’s location.
  - `l04` — **Uncertain** (`uncertain`): Livia says she used the SIM in her coat to message Wren as Nell. The SIM record connects that card to the sending number; the admission is still her account, not an independent record of who typed each message.
- **Claim mapping:**
  - `k7` — Livia wrote the messages sent to Wren. (required Fact record for the listed TRUE/FALSE rule).
  - `k8` — Livia knows where Nell is. (relevant context; this card alone does not satisfy the verdict rule).
- **Known limitation:** Shows: A SIM card in Livia’s coat has the number that sent the messages.; Cannot show: It does not show who wrote them, or where Nell is.

### `x04` — Sender metadata

- **Source:** The messages to Wren
- **Game status:** Fact
- **Exact card content:** “All fourteen messages came from one prepaid number, not Nell’s usual number. Wren got this from the phone company and forwarded it.”
- **Related evidence:**
  - `x02` — **Supports** (`supports`): Every message to Wren has a different sign-off from Nell’s own, and every one came from a single prepaid number that was not Nell’s usual number. Neither fact names the sender.
  - `x03` — **Supports** (`supports`): The SIM in the coat lining has the number that sent all fourteen messages. That links the SIM to the messages, not to the person who wrote them or to Nell’s location.
- **Claim mapping:**
  - `k7` — Livia wrote the messages sent to Wren. (relevant context; this card alone does not satisfy the verdict rule).
- **Known limitation:** Shows: The phone company says all fourteen messages came from one prepaid number, not Nell’s usual number.; Cannot show: It does not identify who used the number, or say what became of Nell.

## Claim rules

The listed related cards are not all required evidence. The rule column records the current engine gate; the “file map” column lists cards associated with the claim for investigation. NULL is a supported result when evidence does not justify TRUE or FALSE.

| ID | Claim | Current ruling | Engine requirements / condition | File map |
|---|---|---|---|---|
| `k1` | MIST capsized at Greywater, and Arlo Penn was later found drowned. | **TRUE** | Fact: `c05`, `c01` | `c05`; `c01` |
<!-- k1 rationale: The photograph records the capsize. The coroner’s note records that Arlo was later found drowned. It does not give his time of death. -->
| `k2` | Livia rescued Nell from the water. | **TRUE** | Fact: `n03`, `c01`; account in file (Fact or Told): `l01` | `c01`; `l01`; `n03` |
<!-- k2 rationale: Nell’s own text says she is alive because of Livia. The photograph shows one person holding another in the water. Livia says she did it. No single card proves it, but together they support it. -->
| `k3` | The records prove the group could have made an emergency voice call at 21:52. | **NULL** | No card prerequisite; use the evidence limits stated in the explanation. | `c02`; `c03` |
<!-- k3 rationale: The records show a text sent at 21:52 and the first emergency call at 22:40, 48 minutes later. A text does not prove that a voice call was possible then. The file does not establish why the call came later, or whether the delay changed anything. -->
| `k4` | Arlo was still alive when “All safe.” was sent. | **NULL** | No card prerequisite; use the evidence limits stated in the explanation. | `c02`; `d02` |
<!-- k4 rationale: Nothing in the file shows when Arlo died. The coroner’s note gives the cause, not the time. -->
| `k5` | The file proves who untied MIST’s rope and that they meant to cause harm. | **NULL** | No card prerequisite; use the evidence limits stated in the explanation. | `d03`; `r02`; `t01`; `c06` |
<!-- k5 rationale: Dess says Arlo untied it. Corin thinks he saw Dess’s hands. Teo is not sure whether he let go. None of those accounts is independently confirmed, and the file does not show anyone meant harm. -->
| `k6` | The 2016 vote was unanimous. | **FALSE** | Fact: `c12` | `c12`; `d05` |
<!-- k6 rationale: The vote sheet shows three different answers: two TRUE, two NULL and one FALSE. -->
| `k7` | Livia wrote the messages sent to Wren. | **NULL by default; conditional when `simFound` is set: TRUE** | Fact: `x03`; account in file (Fact or Told): `l04`; flag: `simFound`; conditional explanation: `simFound` → The SIM in Livia’s coat carried the sending number, and Livia admitted she used it to write the messages as Nell. | `x02`; `x04`; `x03`; `w02`; `x01`; `l04` |
<!-- k7 rationale: The different sign-off and number do not identify who wrote the messages. Without Livia’s admission, the sender is unresolved. -->
| `k8` | Livia knows where Nell is. | **NULL** | No card prerequisite; use the evidence limits stated in the explanation. | `l02`; `l03`; `x03`; `l04` |
<!-- k8 rationale: The SIM card and what Livia told you show that she sent the messages. They do not show she knows where Nell is. She says she does not, and nothing in the file contradicts her. -->
| `k9` | Nell is dead. | **NULL** | No card prerequisite; use the evidence limits stated in the explanation. | `n02`; `b01`; `c11` |
<!-- k9 rationale: Nothing in the file shows that Nell is dead, and nothing shows that she is alive. -->
| `k10` | Nell wrote that she had packed and would not come back to the table. | **TRUE** | Fact: `n02` | `n02`; `n01`; `t03` |
<!-- k10 rationale: Page 2, in her own hand, says so. It does not say where she went or whether she got there. -->

### What each claim does and does not establish

- **`k1` — MIST capsized at Greywater, and Arlo Penn was later found drowned.** The photograph records the capsize. The coroner’s note records that Arlo was later found drowned. It does not give his time of death.
- **`k2` — Livia rescued Nell from the water.** Nell’s own text says she is alive because of Livia. The photograph shows one person holding another in the water. Livia says she did it. No single card proves it, but together they support it.
- **`k3` — The records prove the group could have made an emergency voice call at 21:52.** The records show a text sent at 21:52 and the first emergency call at 22:40, 48 minutes later. A text does not prove that a voice call was possible then. The file does not establish why the call came later, or whether the delay changed anything.
- **`k4` — Arlo was still alive when “All safe.” was sent.** Nothing in the file shows when Arlo died. The coroner’s note gives the cause, not the time.
- **`k5` — The file proves who untied MIST’s rope and that they meant to cause harm.** Dess says Arlo untied it. Corin thinks he saw Dess’s hands. Teo is not sure whether he let go. None of those accounts is independently confirmed, and the file does not show anyone meant harm.
- **`k6` — The 2016 vote was unanimous.** The vote sheet shows three different answers: two TRUE, two NULL and one FALSE.
- **`k7` — Livia wrote the messages sent to Wren.** The different sign-off and number do not identify who wrote the messages. Without Livia’s admission, the sender is unresolved.
  - If `simFound` is set: The SIM in Livia’s coat carried the sending number, and Livia admitted she used it to write the messages as Nell.
- **`k8` — Livia knows where Nell is.** The SIM card and what Livia told you show that she sent the messages. They do not show she knows where Nell is. She says she does not, and nothing in the file contradicts her.
- **`k9` — Nell is dead.** Nothing in the file shows that Nell is dead, and nothing shows that she is alive.
- **`k10` — Nell wrote that she had packed and would not come back to the table.** Page 2, in her own hand, says so. It does not say where she went or whether she got there.

## Confirmed contradiction

| Claim/account | Direct record | What can be established | What remains open |
|---|---|---|---|
| `d05`: “We all wrote NULL. None of us knew what had happened. That’s what the rule is for.” | `c12`: In Corin’s handwriting. Statement: “What happened to Arlo was nobody’s fault.” Dess TRUE. Corin TRUE. Teo NULL. Livia NULL. Nell FALSE. | The vote sheet records two TRUE votes, two NULL votes and one FALSE vote, not a unanimous NULL. The later account is inaccurate against the sheet. | Who first introduced the inaccurate unanimous-NULL version, and why; the sheet does not establish intent or coordination. |

This is the only explicit contradiction entry in the current data. Other differences are represented as supporting context, consistency, uncertainty, or unresolved matters; they are not silently promoted to contradictions.

## Major threads: evidence boundary

| Thread | What the player can establish | What remains possible or unresolved | What the current evidence cannot establish |
|---|---|---|---|
| 2015 capsize and rescue | The boat `MIST` capsized at 20:41; Arlo was found drowned at 07:10. The photograph shows two people at the hull/water; Nell’s text says she is alive because of Livia; Livia gives a matching rescue account. | The separate sources support Livia’s rescue account together. | Arlo’s exact time of death, whether he was alive at 21:52, or the cause/effect of the later call gap. |
| Message and emergency call | Dess’s phone sent “All safe.” at 21:52 from the beach sector; first emergency call was at 22:40, 48 minutes later. Dess admits sending the misleading message; Teo says she wanted the group to agree what to say before calling. | Dess’s stated reason and Teo’s account can inform a theory about the group’s conduct. | Whether a voice call was possible at 21:52, why the interval occurred, whether an earlier call was possible, or whether the interval changed the outcome. |
| Rope | Dess says Arlo untied it; Corin thinks he saw Dess’s hands; Teo cannot remember whether he let go or untied it. | Any of those accounts could be incomplete or mistaken. | Who untied the rope or whether harm was intended. |
| Vote | The sheet records two TRUE, two NULL and one FALSE; the later unanimous-NULL account is wrong. | The person who introduced the later version may have been mistaken or deliberate. | Who introduced it, why, or whether the group coordinated. |
| Nell’s 18:26 text and arrival | Nell texted “nearly there” and asked for the window seat. | She may have arrived later; no arrival record is present. | An arrival time or whether she made it to the house. |
| Nell’s page and departure | Page 2 says Nell packed and would not return to the table; it says Wren knew or would know where she would be. | Her written intention and a plan involving Wren. | Whether she left, where she went, or whether she is alive. |
| Livia and messages to Wren | The number on the SIM found in Livia’s coat sent all fourteen messages; Livia admits using that SIM to write to Wren as Nell. | The admission and records support impersonation of the messages covered by her account. | Livia’s knowledge of Nell’s location, Nell’s fate, or authorship of any messages outside the admission’s scope. |
| Dragged object | Teo says he heard something heavy on the stairs and guessed it might be a bag. Nell’s page says she packed. | A bag is one possibility. | That the object was Nell’s bag or that she left the house. |
| Bus depot | The clerk recalls a girl with a green pack buying a northbound ticket but says he sees many people with packs and is unsure it was Nell. | The sighting could be Nell or another person. | Nell’s identity, destination, or fate. |

## Timeline facts

| Event | Time | Record | Boundary |
|---|---:|---|---|
| Nell texts: “nearly there” | 18:26 | `c07` | Shows: At 18:26, Nell texted that she was nearly there.; Cannot show: The file gives no record of when she arrived. |
| The vote | 22:40 | `c12` | Shows: How each of the five voted.; Cannot show: It does not say why anyone voted as they did. |
| Front door bolted (Dess’s notebook) | 22:55 | `c08` | Shows: Dess wrote that the front door was bolted at 22:55.; Cannot show: It does not say who bolted it. It is Dess’s own note. |
| Livia at Nell’s door (Livia’s account) | 00:10 | `l02` | Shows: Livia says she went to Nell’s door at about 00:10.; Cannot show: It is Livia’s own account. Nobody else saw it. |
| Something dragged downstairs (Teo’s account) | 00:40 | `t03` | Shows: Teo heard a door and something heavy dragged, at about 00:40.; Cannot show: He did not see it. He thinks it was a bag. |
| Dock camera: no boat, no person | 01:15 | `c11` | Shows: No boat and no person at the dock at 01:15.; Cannot show: One moment only. It does not show where anyone went, or anything about Nell’s phone. |

- The 2015 interval from 21:52 to 22:40 is 48 minutes.
- The current source contains no 18:30 shore-arrival event; Nell’s 18:26 text is not an arrival record.
- The 2016 vote night and Nell’s subsequent whereabouts remain separate questions.

## Canon and scope notes

- The working project uses the boat name **MIST**. The supplied brief notes a conflicting earlier direction to use **GOLDIE**; the uploaded working files do not resolve it. This update preserves MIST and leaves the conflict explicit rather than silently renaming the boat.
- No new event, motive, arrival time, cause of death, location, or supernatural explanation has been added by this matrix.
- Main endings retain their existing labels and gates; the matrix describes evidence rules, not a player-facing score.
