# NULL: The Fifth Chair — implementation plan

## Uddeshya

Uploaded `NULL-overhaul-humanized-final.zip` ko source of truth bana kar writing-block.md ke mutabiq focused audit-remediation karni hai. Saath diya gaya `index.html` ZIP ke entry file se byte-for-byte identical hai; usay alag se maintain nahin karunga. Existing static, offline HTML/CSS/JavaScript architecture, current visual identity, game functionality, Roman Urdu, aur saat endings ko preserve karna hai. Koi framework, API, backend, database, ya paid service add nahin hogi.

## Implementation

1. **Evidence aur contradiction model:** Har card, claim, source, relation, limitation, aur unresolved sawal ka source-to-claim matrix tayyar karna. `d04`/`c02` ki alleged signal contradiction, uncertain rope testimony ke categorical contradictions, aur `l03`/`x03` se Nell tak pohanch ka inference dobara sahi classify karna. Nell ke 18:26 “nearly there” text ko arrival record na samajhna; current file arrival time nahin deti, is liye 18:30 ko UI ya locale mein state nahin karna. Livia ki admission ko impersonation tak mahdood rakhna; us se Nell ka thikana ya tamam messages ka author prove nahin hoga.
2. **Verdict aur endings:** Existing TRUE/FALSE/NULL rules, seven current ending names, their gates, and deterministic logic ko preserve karna. Player-facing TRUE/FALSE/NULL totals, supported-claim counts, aur numeric ending-progress disclosure hataana; evidence-specific narrative feedback rakhna taa-ke player ko apne report ki kami samajh aaye magar internal score na dikhe.
3. **Investigation workspace:** Maujooda evidence collection, card comparison, pins aur board ko rakhtay hue player ke apne notes aur open questions add karna. Yeh current screen se khulne wale compact panel mein hon; local save mein persist hon, reload ke baad recover hon, language switch par na khoen, aur corrupt/old save se safe recovery tests hon. Notes aur unresolved questions ko static editor notes se alag dikhana.
4. **Canon, story, aur docs:** MIST ko working name hi rakhna; GOLDIE conflict par andaza laga kar rename nahin karna. Current story bible aur ending identities preserve karna. Source-to-claim/contradiction map, hidden evaluation rules, ending gates, open canon decisions, run/deploy instructions aur test limitations documentation mein record karna. Production host specify na hone ki wajah se host-specific config invent nahin karni; static hosting ke liye directory structure preserve karne ki general hidayat deni.
5. **UI aur localization:** Existing dark archival dossier design aur English/Pakistani Roman Urdu system ko continue karna. Mobile language control ko subtle, borderless three-line hamburger banana; open state mein bars smooth, restrained X banain. Dropdown English/Roman Urdu options de, selection/outside click/Escape par band ho, aur nav/wordmark ko overlap na kare; desktop direct buttons same rahen. Notes ko nav se nikal kar investigation screens par fixed, small notebook-icon shortcut banana; desktop par side drawer aur mobile par safe-area-aware bottom sheet open ho. Existing local autosave, questions, keyboard focus, tab/scroll restoration and translations preserve hon; content ke neeche enough space ho taa-ke shortcut important actions ko na dhake. Title wordmark ke neeche exact `| by 850101 |` muted signature ho. Har nayi visible/accessibility string dono zabanon mein ho, signature exact rahe, aur reduced motion respect ho.
6. **Verification:** Har fix ke liye regression tests add/update; `node tests/run.js`, locale builder aur `python3 tests/browser.py` chalana. Seven endings ki reachability, hidden numeric score, note/question persistence, corrupted save recovery, both languages, mobile/desktop overflow, browser errors aur assets check karna. Jo browser/device/deployment coverage maujood na ho usay limitation ke taur par report karna.

## Design faislay

- **Design movement:** Dark archival case-file / forensic dossier; maujooda project ki visual direction ko extend karna, naya brand ya style introduce nahin karna.
- **Core principles:** Records aur interpretations ko alag rakhna; har conclusion ka source traceable ho; uncertainty ko exact rakhna; interface investigation ko asaan kare, answer na bataye.
- **Color philosophy:** Near-black/charcoal paper-like backgrounds; muted warm neutrals for records; restrained dark-red accents sirf urgent/conflicted details ke liye; text contrast aur status ko color par akela depend na karna.
- **Layout paradigm:** Current desk/screen navigation aur evidence board ko preserve karna; optional clipboard side-panel current investigation context ke upar khulay.
- **Signature elements:** Evidence slips with source/status; timeline stamps; Nell ke khaali window-side seat ka restrained motif.
- **Interaction/animation:** Pin, compare, annotate, and review without changing screens; no answer auto-reveal. Transitions subtle, readable, and reduced-motion-aware.
- **Typography:** Existing bundled Inter/Lora pairing preserve; no remote fonts.
- **Brand essence:** Evidence-limited psychological investigation for careful readers; restrained, forensic, unsettling. Voice direct, human, and never claims more than the file supports.
- **Wordmark/logo/color:** Existing NULL wordmark/favicon and restrained oxblood accent preserve; no new logo asset needed.

## Project structure aur responsibilities

- `index.html`: static app shell, local script loading, language controls, landmarks.
- `css/style.css`: visual system, responsive layouts, focus and reduced-motion behavior.
- `js/data-facts.js`, `js/data-cards.js`, `js/data-interviews.js`, `js/data-links.js`, `js/data-story.js`: story source, records, claims, relationships, and endings.
- `js/engine.js`: deterministic investigation state, verdict validation, save migration, endings.
- `js/ui.js`, `js/ui-kit.js`, `js/art.js`: investigation screens, dialogs/panel, and art metadata.
- `locales/roman-urdu/*.json`, `js/i18n.js`, generated `js/data-locale.js`: editable Urdu copy, fallback/runtime, generated bundle.
- `tests/run.js`, `tests/browser.py`: logic, persistence, localization, accessibility interaction, layout, and ending regression coverage.
- `STORY_BIBLE.md`, `CANON_AUDIT.md`, `CHANGELOG.md`, `PROJECT_STATE.md`, plus a new evidence matrix: author-facing story/evidence rules and delivery notes.

## Dependencies aur serving

Koi nayi dependency nahin. Project static/offline hi rahega: root folder ko existing instructions ke mutabiq `python3 -m http.server 8000` se serve kiya ja sakta hai. Backend/database/API ka koi role nahin. Production provider specify nahin, isliye sirf relative paths aur complete root folder ki general static-host instructions dunga. Final delivery updated ZIP hogi; original uploaded ZIP aur standalone HTML ko untouched reference inputs ke taur par rakha jayega.
