The original project as you supplied it, before any changes.

null-overhaul-pre-review.zip: the project exactly as it was before the final quality-review pass (it also contains null-original.zip). null-original.zip itself is untouched.
