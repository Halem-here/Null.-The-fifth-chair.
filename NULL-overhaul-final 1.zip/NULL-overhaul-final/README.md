# NULL — The Fifth Chair

A static, offline browser mystery game about a boat, a vote, and the story a group agreed to tell.

## Run the game

No installation or build step is required. From this folder, run:

```sh
python3 -m http.server 8000
```

Then open <http://localhost:8000>. Serving the files this way is recommended because storage behavior for directly opened `file://` pages varies by browser. Progress is stored only in that browser; it is not sent to a server.

On desktop, use the language buttons at the top to switch between **English** and **Pakistani Roman Urdu** (Latin script). On phones, tap the upper-right hamburger; its three lines animate into an X while the language choices are open. Your language preference is saved separately from your game progress; changing it does not reset the investigation. The title screen carries the understated signature `| by 850101 |` beneath NULL.

## Investigation notebook

Use the fixed bottom-right **My notes** shortcut on any investigation screen to keep personal notes and open questions without leaving the current page. Notes opens as a side drawer on desktop and a bottom sheet on phones. Notes, questions, and evidence pins are saved in this browser only; they are not sent to a server or encrypted. Switching languages or refreshing the page does not clear them. **New game** clears them with the rest of the local save.

## Story and evidence reference

`STORY_BIBLE.md` describes the working story and its open questions. `EVIDENCE_MATRIX.md` maps every current evidence card to its source, links, limitations, and relevant claim rules. The project is an internal working draft, not verified against an external canon packet.

## Tests and locale maintenance

```sh
node tests/run.js
python3 tests/browser.py
```

The browser suite needs Playwright and its Chromium browser. The editable Roman Urdu JSON files are in `locales/roman-urdu/`; rebuild the bundled, offline catalog after editing them with:

```sh
python3 tools/build-locale.py
```

Latest verified results: `node tests/run.js` — **130 passed, 0 failed**; `python3 tests/browser.py` — **328 passed, 0 failed** in Chromium/Playwright.

## Story note

This project is the working story draft; there is no separate canon packet being treated as authority. `STORY_BIBLE.md` records the current design, established evidence and open mysteries. `CANON_AUDIT.md` is an internal consistency review, not an external canon check.
