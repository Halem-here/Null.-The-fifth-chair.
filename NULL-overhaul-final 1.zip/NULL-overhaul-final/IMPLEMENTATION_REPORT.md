# NULL — Implementation Handoff

## 1. What was corrected

The supplied project is a static, offline mystery; its working architecture was preserved rather than replaced. The player-facing ending no longer exposes numeric tallies or supported-claim counts. It explains the report qualitatively using the records, verdicts and retelling choices, while the existing deterministic ending gates remain intact.

The evidence relationships were checked against the underlying cards and claim rules. The board treats the 21:52 message and 22:40 call as context for the delay, not proof that a voice call was possible at 21:52. Rope accounts and the relationship between Livia's earlier “I don't have her number any more” statement and the later SIM admission are not promoted to unsupported contradictions. The vote sheet versus the later unanimous-NULL account remains the one explicit confirmed contradiction.

The live English story already states that Nell's 18:26 text is not an arrival record. Old, unused Roman Urdu entries still implied an 18:30 arrival and retained deleted tally/contradiction copy; these were removed from the editable catalog and generated bundle. Regression checks now guard against their return. No new time, clue, motive, culprit, death explanation, location or supernatural event was added.

The investigation notebook stores the player's notes and open questions alongside the existing saved progress. Notes, questions and evidence pins survive reload and language switching in the local browser save; they are not sent to a server. Documentation now explains this local-only behavior and the static run/deploy setup.

## 2. Canon-preserving story decisions

No new authoritative canon was available, so changes preserve the supplied working draft rather than choosing new story facts. The 48-minute interval does not explain why the call came later, whether an earlier voice call was possible, whether Arlo was alive at 21:52, or whether the delay changed the outcome. Dess's message and Teo's account remain distinct sources. Livia's admission establishes impersonation only within its stated scope; it does not establish Nell's fate or Livia's knowledge of it. Nell's page and Teo's account of a dragged object do not prove whether she left or what the object was. The rope actor and intent remain unresolved.

The story keeps five friends and five chairs. The empty fifth chair is Nell's place and missing perspective, not a sixth chair for Arlo. The uploaded brief notes a conflict between MIST and an earlier GOLDIE instruction. The project retains MIST and documents that unresolved author decision; it does not silently rename the boat.

`STORY_BIBLE.md` describes what the player knows at the start, what the file establishes, and what remains open. `CANON_AUDIT.md` records the working-draft limits and verification caveats.

## 3. Evidence-to-claim map

See [`EVIDENCE_MATRIX.md`](EVIDENCE_MATRIX.md) for the full map: **34 cards, 10 claims, 24 board links, and 1 explicit contradiction**. For every card it records the source, game status, exact card content, relevant links, claim role and known limits. The claim table distinguishes a relevant lead from an actual `needs`, `needsAccount` or conditional verdict prerequisite.

The only explicit contradiction is the vote sheet (`c12`) against the later unanimous-NULL account (`d05`). The sheet shows the later account is inaccurate. It does not establish who introduced it or whether anyone coordinated it. The matrix also separates the capsizing/call interval, the 2016 vote, Nell's messages and page, Livia's SIM admission, Teo's memory and the unresolved rope question into what the player can establish, what remains plausible and what cannot be concluded.

## 4. Seven endings and hidden evaluation

The current seven ending identities and gate order were preserved:

1. **STRUCK** — the player's weight for striking out cards not contradicted by a Fact reaches the existing threshold.
2. **THE SAME SENTENCE** — at least two retelling choices repeat the group's agreed line.
3. **NELL / THE FIVE** — Nell is addressed after the required Wren-forwarded, timeline, page, evidence-classification and claim-support requirements are met.
4. **THE CARD** — Livia is addressed after the SIM is found and classed Fact, the existing trust threshold is met, and `k7` and `k8` are supported.
5. **THE LETTER** — Wren is addressed after the existing trust, forwarded-record, evidence and claim requirements are met.
6. **THE FIVE** — all eight core claims (`k1`, `k3`–`k9`) are supported.
7. **NO ANSWER** — fallback when the completed report does not meet another gate.

The implementation was not relabelled to match proposed ending names that conflict with the existing project; the brief explicitly says to preserve existing names and gates unless canon resolves the difference. The existing deterministic rules keep separate factors rather than one aggregate score: evidence accuracy is reflected by evidence classifications, invalid strikes and supported claim states; reasoning by whether conclusions exceed those states and by the retelling choices; the final report by its verdicts, recipient and ending-specific requirements. This maps the requested themes onto the current gates instead of introducing a new normalized three-axis scale. The ending UI reveals neither numeric counts nor a “best ending” label. It gives evidence-specific qualitative explanations and does not treat legitimate uncertainty as proof of failure.

## 5. Frontend, localization and accessibility

The existing dark archival dossier style, bundled fonts, evidence board, card inspection, timelines and interview flow were retained. A fixed bottom-right Notes shortcut pairs a small open-book illustration and red ribbon with a clear “My notes” label; it opens a mobile bottom sheet or desktop side drawer without leaving the current screen. Regressions cover access across investigation tabs, focus/scroll restoration, the book icon and label, and persistence of notes, questions and pins. On screens 560px wide and narrower, a minimal hamburger animates into an X and opens the English/Roman Urdu choices; desktop keeps the direct buttons. The exact `| by 850101 |` signature sits directly under the NULL wordmark. Changing language leaves the active investigation intact.

English and Pakistani Roman Urdu remain supported, with Urdu in Latin script. The generated catalog contains **869 exact entries and 90 patterns**. Tests cover rendered screens and endings in both languages, mobile/desktop layout, dialogs, keyboard interactions, save persistence, image loading, missing translations, browser errors and unexpected requests.

## 6. Commands and results

- `python3 tools/build-locale.py` — completed; **869 exact entries, 90 patterns**.
- `node tests/run.js` — **130 passed, 0 failed**.
- `python3 tests/browser.py` — **328 passed, 0 failed** in Chromium/Playwright, including the open-book shortcut, Notes sheet/drawer, language-menu, viewport, persistence and all-ending regressions.
- JavaScript syntax checks for project scripts — passed.
- `python3 -m py_compile tools/build-locale.py tests/browser.py` — passed.
- All editable Roman Urdu JSON files parsed successfully.
- `node tests/probes/ending-gates.js` — diagnostic only, not a pass/fail suite; with its intentionally incomplete probe state it returned `NO ANSWER` because `k7`, sign-off and `x02` were not established. The main regression suite separately checks all seven ending routes.

Browser runs use Chromium/Playwright: 390×844 touch emulation and 1280×800 desktop for the full game, plus a 320px menu-fit check. Safari, Firefox and physical-device testing were not performed.

## 7. Open decisions and deployment

The MIST/GOLDIE conflict is unresolved. There is no supplied authoritative canon packet. A full human literary review of every English and Roman Urdu line remains outstanding; automated coverage checks do not judge voice or cultural nuance. No production host was specified and no deployment was performed.

To run locally, from the project root use:

```sh
python3 -m http.server 8000
```

Then open `http://localhost:8000`. For deployment, publish the project root to any ordinary static host without changing the relative `css/`, `js/`, `assets/` and `locales/` paths. There is no build step, backend, database, remote API or server-side save service. Do not treat browser tests as a security audit or hosting certification.
